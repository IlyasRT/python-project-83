from flask import Flask, render_template
from dotenv import load_dotenv
import os
import psycopg2


load_dotenv()
app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')



@app.route('/')
def hello_world():
    # return 'Проверка --> Welcome to Flask!'
    # return render_template('index.html')
    return render_template('index2.html')
    
