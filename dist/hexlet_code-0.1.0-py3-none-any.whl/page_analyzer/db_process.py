import os
import datetime
import psycopg2
from dotenv import load_dotenv

load_dotenv()
