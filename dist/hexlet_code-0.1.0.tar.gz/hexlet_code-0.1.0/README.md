### Hexlet tests and linter status:
[![Actions Status](https://github.com/IlyasRT/python-project-83/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/IlyasRT/python-project-83/actions)