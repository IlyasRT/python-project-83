class Configurations:
    debug = True
